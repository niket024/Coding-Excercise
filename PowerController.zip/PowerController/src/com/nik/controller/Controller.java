package com.nik.controller;


public interface Controller
{
	void control();
	
}
