package com.nik.util;

public interface Constants
{
	String ON = "ON";
	String OFF = "OFF";
	int BULB_POWER_UNITS = 5;
	int AC_POWER_UNITS = 10;
}
